// Mobile menu
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const mobileNav = document.getElementById('mobileNav');
if (mobileMenuBtn) {
  mobileMenuBtn.addEventListener('click', () => {
    mobileNav.classList.toggle('open');
    mobileMenuBtn.innerHTML = mobileNav.classList.contains('open')
      ? '<i class="fa-solid fa-xmark"></i>'
      : '<i class="fa-solid fa-bars"></i>';
  });
}

// Notification dropdown
const notifBtn = document.getElementById('notifBtn');
const notifDropdown = document.getElementById('notifDropdown');
if (notifBtn) {
  let loaded = false;
  notifBtn.addEventListener('click', async (e) => {
    e.stopPropagation();
    notifDropdown.classList.toggle('open');
    if (!loaded && notifDropdown.classList.contains('open')) {
      try {
        const res = await fetch('/api/notifications');
        const notifs = await res.json();
        loaded = true;
        if (notifs.length === 0) {
          notifDropdown.innerHTML = '<div class="notif-item"><p>No notifications yet.</p></div>';
        } else {
          notifDropdown.innerHTML = notifs.map(n =>
            `<div class="notif-item"><p>${n.message}</p><small>${n.time}</small></div>`
          ).join('');
        }
      } catch {
        notifDropdown.innerHTML = '<div class="notif-item"><p>Could not load.</p></div>';
      }
    }
  });
  document.addEventListener('click', () => notifDropdown.classList.remove('open'));
}

// Password toggle
function togglePw(fieldId, btn) {
  const field = document.getElementById(fieldId);
  if (field.type === 'password') {
    field.type = 'text';
    btn.innerHTML = '<i class="fa-regular fa-eye-slash"></i>';
  } else {
    field.type = 'password';
    btn.innerHTML = '<i class="fa-regular fa-eye"></i>';
  }
}

// Auto-dismiss flash messages after 5s
setTimeout(() => {
  document.querySelectorAll('.flash').forEach(f => {
    f.style.transition = 'opacity 0.5s, transform 0.5s';
    f.style.opacity = '0';
    f.style.transform = 'translateX(100%)';
    setTimeout(() => f.remove(), 500);
  });
}, 5000);

// File input label update
const resumeInput = document.getElementById('resumeInput');
if (resumeInput) {
  resumeInput.addEventListener('change', function () {
    const label = this.nextElementSibling;
    const span = label.querySelector('span');
    if (span) span.textContent = this.files[0] ? this.files[0].name : 'Choose file…';
  });
}

// Animate stats on scroll
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.job-card, .job-list-card, .step, .dash-stat').forEach((el, i) => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(20px)';
  el.style.transition = `opacity 0.4s ease ${i * 0.05}s, transform 0.4s ease ${i * 0.05}s`;
  observer.observe(el);
});
