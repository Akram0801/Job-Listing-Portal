from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'jobportal-secret-key-2024')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///jobportal.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads/resumes'
app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024  # 5MB

ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}

db = SQLAlchemy(app)

# ── Models ──────────────────────────────────────────────────────────────────

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'seeker' or 'employer'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    # Seeker fields
    phone = db.Column(db.String(20))
    location = db.Column(db.String(100))
    resume = db.Column(db.String(256))
    skills = db.Column(db.Text)
    bio = db.Column(db.Text)
    # Employer fields
    company_name = db.Column(db.String(150))
    company_website = db.Column(db.String(200))
    company_description = db.Column(db.Text)
    industry = db.Column(db.String(100))

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    employer_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    qualifications = db.Column(db.Text)
    responsibilities = db.Column(db.Text)
    location = db.Column(db.String(100))
    job_type = db.Column(db.String(50))  # Full-time, Part-time, etc.
    salary_min = db.Column(db.Integer)
    salary_max = db.Column(db.Integer)
    category = db.Column(db.String(100))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    employer = db.relationship('User', backref='jobs')

class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('job.id'), nullable=False)
    seeker_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    cover_letter = db.Column(db.Text)
    status = db.Column(db.String(30), default='Pending')  # Pending, Reviewed, Shortlisted, Rejected
    applied_at = db.Column(db.DateTime, default=datetime.utcnow)
    job = db.relationship('Job', backref='applications')
    seeker = db.relationship('User', backref='applications')

# ── Helpers ──────────────────────────────────────────────────────────────────

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def login_required(role=None):
    def decorator(f):
        from functools import wraps
        @wraps(f)
        def wrapper(*args, **kwargs):
            if 'user_id' not in session:
                flash('Please log in to continue.', 'warning')
                return redirect(url_for('login'))
            if role and session.get('user_role') != role:
                flash('Access denied.', 'danger')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return wrapper
    return decorator

# ── Auth Routes ──────────────────────────────────────────────────────────────

@app.route('/')
def index():
    jobs = Job.query.filter_by(is_active=True).order_by(Job.created_at.desc()).limit(6).all()
    total_jobs = Job.query.filter_by(is_active=True).count()
    total_companies = db.session.query(db.func.count(db.distinct(Job.employer_id))).scalar()
    total_seekers = User.query.filter_by(role='seeker').count()
    return render_template('index.html', jobs=jobs, total_jobs=total_jobs,
                           total_companies=total_companies, total_seekers=total_seekers)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        role = request.form.get('role', 'seeker')
        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
            return redirect(url_for('register'))
        user = User(
            name=name, email=email,
            password=generate_password_hash(password),
            role=role
        )
        db.session.add(user)
        db.session.commit()
        session['user_id'] = user.id
        session['user_role'] = user.role
        session['user_name'] = user.name
        flash('Account created successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['user_role'] = user.role
            session['user_name'] = user.name
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid email or password.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

# ── Dashboard ────────────────────────────────────────────────────────────────

@app.route('/dashboard')
@login_required()
def dashboard():
    user = User.query.get(session['user_id'])
    if user.role == 'employer':
        jobs = Job.query.filter_by(employer_id=user.id).order_by(Job.created_at.desc()).all()
        total_apps = sum(len(j.applications) for j in jobs)
        return render_template('dashboard_employer.html', user=user, jobs=jobs, total_apps=total_apps)
    else:
        apps = Application.query.filter_by(seeker_id=user.id).order_by(Application.applied_at.desc()).all()
        return render_template('dashboard_seeker.html', user=user, apps=apps)

# ── Jobs ─────────────────────────────────────────────────────────────────────

@app.route('/jobs')
def jobs():
    q = request.args.get('q', '')
    location = request.args.get('location', '')
    job_type = request.args.get('job_type', '')
    min_salary = request.args.get('min_salary', '')
    max_salary = request.args.get('max_salary', '')
    query = Job.query.filter_by(is_active=True)
    if q:
        query = query.filter(Job.title.ilike(f'%{q}%') | Job.description.ilike(f'%{q}%'))
    if location:
        query = query.filter(Job.location.ilike(f'%{location}%'))
    if job_type:
        query = query.filter(Job.job_type == job_type)
    if min_salary:
        query = query.filter(Job.salary_min >= int(min_salary))
    if max_salary:
        query = query.filter(Job.salary_max <= int(max_salary))
    all_jobs = query.order_by(Job.created_at.desc()).all()
    return render_template('jobs.html', jobs=all_jobs, q=q, location=location,
                           job_type=job_type, min_salary=min_salary, max_salary=max_salary)

@app.route('/jobs/<int:job_id>')
def job_detail(job_id):
    job = Job.query.get_or_404(job_id)
    already_applied = False
    if 'user_id' in session:
        already_applied = Application.query.filter_by(
            job_id=job_id, seeker_id=session['user_id']).first() is not None
    return render_template('job_detail.html', job=job, already_applied=already_applied)

@app.route('/jobs/new', methods=['GET', 'POST'])
@login_required('employer')
def new_job():
    if request.method == 'POST':
        job = Job(
            employer_id=session['user_id'],
            title=request.form.get('title'),
            description=request.form.get('description'),
            qualifications=request.form.get('qualifications'),
            responsibilities=request.form.get('responsibilities'),
            location=request.form.get('location'),
            job_type=request.form.get('job_type'),
            salary_min=int(request.form.get('salary_min') or 0),
            salary_max=int(request.form.get('salary_max') or 0),
            category=request.form.get('category'),
        )
        db.session.add(job)
        db.session.commit()
        flash('Job posted successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('job_form.html', job=None)

@app.route('/jobs/<int:job_id>/edit', methods=['GET', 'POST'])
@login_required('employer')
def edit_job(job_id):
    job = Job.query.get_or_404(job_id)
    if job.employer_id != session['user_id']:
        flash('Access denied.', 'danger')
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        job.title = request.form.get('title')
        job.description = request.form.get('description')
        job.qualifications = request.form.get('qualifications')
        job.responsibilities = request.form.get('responsibilities')
        job.location = request.form.get('location')
        job.job_type = request.form.get('job_type')
        job.salary_min = int(request.form.get('salary_min') or 0)
        job.salary_max = int(request.form.get('salary_max') or 0)
        job.category = request.form.get('category')
        db.session.commit()
        flash('Job updated successfully!', 'success')
        return redirect(url_for('dashboard'))
    return render_template('job_form.html', job=job)

@app.route('/jobs/<int:job_id>/delete', methods=['POST'])
@login_required('employer')
def delete_job(job_id):
    job = Job.query.get_or_404(job_id)
    if job.employer_id != session['user_id']:
        flash('Access denied.', 'danger')
        return redirect(url_for('dashboard'))
    Application.query.filter_by(job_id=job_id).delete()
    db.session.delete(job)
    db.session.commit()
    flash('Job deleted.', 'info')
    return redirect(url_for('dashboard'))

# ── Applications ─────────────────────────────────────────────────────────────

@app.route('/jobs/<int:job_id>/apply', methods=['POST'])
@login_required('seeker')
def apply_job(job_id):
    job = Job.query.get_or_404(job_id)
    if Application.query.filter_by(job_id=job_id, seeker_id=session['user_id']).first():
        flash('You have already applied for this job.', 'warning')
        return redirect(url_for('job_detail', job_id=job_id))
    app_obj = Application(
        job_id=job_id,
        seeker_id=session['user_id'],
        cover_letter=request.form.get('cover_letter', '')
    )
    db.session.add(app_obj)
    db.session.commit()
    flash('Application submitted successfully!', 'success')
    return redirect(url_for('dashboard'))

@app.route('/jobs/<int:job_id>/applications')
@login_required('employer')
def view_applications(job_id):
    job = Job.query.get_or_404(job_id)
    if job.employer_id != session['user_id']:
        flash('Access denied.', 'danger')
        return redirect(url_for('dashboard'))
    apps = Application.query.filter_by(job_id=job_id).order_by(Application.applied_at.desc()).all()
    return render_template('applications.html', job=job, apps=apps)

@app.route('/applications/<int:app_id>/status', methods=['POST'])
@login_required('employer')
def update_app_status(app_id):
    application = Application.query.get_or_404(app_id)
    application.status = request.form.get('status', 'Pending')
    db.session.commit()
    flash('Application status updated.', 'success')
    return redirect(request.referrer or url_for('dashboard'))

# ── Profile ───────────────────────────────────────────────────────────────────

@app.route('/profile', methods=['GET', 'POST'])
@login_required()
def profile():
    user = User.query.get(session['user_id'])
    if request.method == 'POST':
        user.name = request.form.get('name', user.name)
        user.phone = request.form.get('phone')
        user.location = request.form.get('location')
        user.bio = request.form.get('bio')
        user.skills = request.form.get('skills')
        user.company_name = request.form.get('company_name')
        user.company_website = request.form.get('company_website')
        user.company_description = request.form.get('company_description')
        user.industry = request.form.get('industry')
        # Resume upload
        if 'resume' in request.files:
            file = request.files['resume']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{user.id}_{file.filename}")
                os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                user.resume = filename
        session['user_name'] = user.name
        db.session.commit()
        flash('Profile updated successfully!', 'success')
        return redirect(url_for('profile'))
    return render_template('profile.html', user=user)

# ── Notifications (simple JSON endpoint) ─────────────────────────────────────

@app.route('/api/notifications')
@login_required()
def notifications():
    user_id = session['user_id']
    role = session['user_role']
    notifs = []
    if role == 'employer':
        recent_apps = Application.query.join(Job).filter(
            Job.employer_id == user_id
        ).order_by(Application.applied_at.desc()).limit(5).all()
        for a in recent_apps:
            notifs.append({
                'message': f'{a.seeker.name} applied for {a.job.title}',
                'time': a.applied_at.strftime('%b %d, %Y')
            })
    else:
        recent_apps = Application.query.filter_by(seeker_id=user_id).order_by(
            Application.applied_at.desc()).limit(5).all()
        for a in recent_apps:
            notifs.append({
                'message': f'Your application for {a.job.title} is {a.status}',
                'time': a.applied_at.strftime('%b %d, %Y')
            })
    return jsonify(notifs)

# ── Init DB ───────────────────────────────────────────────────────────────────

with app.app_context():
    db.create_all()
    # Seed demo data if empty
    if not User.query.first():
        emp = User(name='Acme Corp', email='employer@demo.com',
                   password=generate_password_hash('demo1234'),
                   role='employer', company_name='Acme Corp',
                   company_description='A leading tech company.', industry='Technology')
        seek = User(name='Jane Doe', email='seeker@demo.com',
                    password=generate_password_hash('demo1234'),
                    role='seeker', skills='Python, JavaScript, React',
                    bio='Passionate full-stack developer.')
        db.session.add_all([emp, seek])
        db.session.flush()
        jobs_demo = [
            Job(employer_id=emp.id, title='Senior Python Developer',
                description='Build scalable backend services.', location='Chennai, TN',
                job_type='Full-time', salary_min=80000, salary_max=120000,
                category='Engineering', qualifications='3+ years Python',
                responsibilities='Design APIs, mentor juniors'),
            Job(employer_id=emp.id, title='React Frontend Engineer',
                description='Create beautiful UIs.', location='Remote',
                job_type='Remote', salary_min=60000, salary_max=90000,
                category='Engineering', qualifications='2+ years React',
                responsibilities='Build components, optimize performance'),
            Job(employer_id=emp.id, title='Data Analyst',
                description='Analyze business data.', location='Bengaluru, KA',
                job_type='Full-time', salary_min=50000, salary_max=70000,
                category='Data', qualifications='SQL, Python, Excel',
                responsibilities='Create reports, dashboards'),
        ]
        db.session.add_all(jobs_demo)
        db.session.commit()

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
